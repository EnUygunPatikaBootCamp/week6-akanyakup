<?php

namespace App\Controller;

use App\Entity\Product;
use App\Repository\ProductRepository;
use Doctrine\Persistence\ManagerRegistry;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ProductController extends AbstractController
{
    #[Route('/product', name: 'app_product', methods: ['GET', 'HEAD'])]
    public function index(ManagerRegistry $doctrine): JsonResponse
    {
        $repository = $doctrine->getRepository(Product::class);
        $products = $repository->findAll();

        return new JsonResponse($products);
    }

    #[Route('/product', name: 'create_product', methods: ['POST'])]
    public function createProduct(ManagerRegistry $doctrine): JsonResponse
    {
        $entityManager = $doctrine->getManager();

        $date = new \DateTime('@'.strtotime('now'));

        $product = new Product();
        $product->setName('Monitor');
        $product->setPrice(3999);
        $product->setDescription('Colored!');
        $product->setNumber(45);
        $product->setDate($date);
        $entityManager->persist($product);

        $entityManager->flush();

        return new JsonResponse('Saved new product with id '.$product->getId());
    }

    /*#[Route('/product/{id}', name: 'product_show', methods: ['GET','HEAD'])]
    public function show(ManagerRegistry $doctrine, int $id): Response
    {
        $product = $doctrine->getRepository(Product::class)->find($id);

        if (!$product) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        return new Response('Check out this great product: '.$product->getName());
    }*/

    #[Route('/product/{id}', name: 'app_bul', methods: ['GET','HEAD'])]
    public function kitapSecim(Product $product): JsonResponse
    {
        
        
        return new JsonResponse('name =>'.$product->getName());
    }

    #[Route('/product/{id}', name: 'product_edit', methods: ['PUT'])]
    public function update(ManagerRegistry $doctrine, int $id): JsonResponse
    {
        $entityManager = $doctrine->getManager();
        $product = $entityManager->getRepository(Product::class)->find($id);

        if (!$product) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        $product->setName('New product name!');
        $entityManager->flush();

        /*return $this->redirectToRoute('product_show', [
            'id' => $product->getId()
        ]);*/
        return new JsonResponse ('Veriniz güncellenmiştir.'.$product->getId());
    }

    #[Route('/product/{id}', name: 'product_delete', methods: ['DELETE'])]
    public function delete(ManagerRegistry $doctrine, int $id): JsonResponse
    {
        $entityManager = $doctrine->getManager();
        $product = $entityManager->getRepository(Product::class)->find($id);

        if (!$product) {
            throw $this->createNotFoundException(
                'No product found for id '.$id
            );
        }

        $entityManager->remove($product);
        $entityManager->flush();

        return new JsonResponse('Veriniz silinmiştir');
    }
}
